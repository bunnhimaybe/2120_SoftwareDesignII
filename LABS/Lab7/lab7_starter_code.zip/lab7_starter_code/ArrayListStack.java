import java.util.ArrayList;

public class ArrayListStack <T> implements Stack<T> {

	private ArrayList<T> elements;
	
	public ArrayListStack() {

	}
	
    @Override
	public int size() {

	}
	
    @Override
	public boolean isEmpty() {

	}
	
    // this is the "insert" operation
    // in a stack, new items are inserted at the "top" of the stack
    @Override
	public void push(T item) {

	}
	
    // this is the "return but don't delete" operation
    // in a stack, the "next" items are returned from the "top" of the stack
    @Override
	public T peek() {

	}
	
    // this is the "delete and return" operation
    // in a stack, the "next" items are deleted from the "top" of the stack 
    @Override
	public T pop() {

	}
	
} // end class ArrayListStack
